
// script.js - simple interactions: login (localStorage), nav, audio control
document.addEventListener('DOMContentLoaded', function(){
  // login form submit
  const loginForm = document.getElementById('login-form');
  if(loginForm){
    loginForm.addEventListener('submit', function(e){
      e.preventDefault();
      const nama = document.getElementById('nama').value.trim();
      const kelas = document.getElementById('kelas').value.trim();
      const nis = document.getElementById('nis').value.trim();
      if(!nama || !kelas || !nis){ alert('Mohon isi semua kolom!'); return; }
      localStorage.setItem('ed_nama', nama);
      localStorage.setItem('ed_kelas', kelas);
      localStorage.setItem('ed_nis', nis);
      // redirect to modules page
      window.location.href = 'modules/module1.html';
    }, false);
  }

  // display nama on top if available
  const userDisplay = document.getElementById('user-display');
  if(userDisplay){
    const n = localStorage.getItem('ed_nama');
    if(n) userDisplay.textContent = n;
  }

  // audio controls
  const audio = document.getElementById('bg-audio');
  const audioToggle = document.getElementById('audio-toggle');
  if(audio && audioToggle){
    audioToggle.addEventListener('click', function(){
      if(audio.paused){ audio.play(); audioToggle.textContent='Pause Music'; }
      else { audio.pause(); audioToggle.textContent='Play Music'; }
    });
  }
});
